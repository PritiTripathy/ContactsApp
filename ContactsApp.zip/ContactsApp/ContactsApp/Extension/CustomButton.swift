//
//  CustomButton.swift
//  ContactsApp
//
//
//  Created by Pritimay Tripathy on 26/07/18.
//  Copyright © 2018 Pritimay Tripathy. All rights reserved.
//

import UIKit

class CustomButton: UIButton {

    @IBInspectable var buttonCornerRadius : CGFloat = 0.0 {
        didSet {
            layer.cornerRadius = buttonCornerRadius
        }
    }
    
    @IBInspectable var buttonBorderColor : UIColor = UIColor.clear {
        didSet {
            //RGB: 0/255-128/255-64/255
            layer.borderColor = buttonBorderColor.cgColor
        }
    }
    
    @IBInspectable var buttonBorderWidth : CGFloat = 0.0 {
        didSet {
            layer.borderWidth = buttonBorderWidth
        }
    }
    
    /*
     // Only override draw() if you perform custom drawing.
     // An empty implementation adversely affects performance during animation.
     override func draw(_ rect: CGRect) {
     // Drawing code
     }
     */
    public override func awakeFromNib() {
        self.titleEdgeInsets = UIEdgeInsetsMake(0.5, 5.0, 0.0, 0.0)
    }

}
