//
//  CountryListTableViewCell.swift
//  ContactsApp
//
//  Created by Pritimay Tripathy on 23/07/18.
//  Copyright © 2018 Pritimay Tripathy. All rights reserved.
//

import UIKit

class CountryListTableViewCell: UITableViewCell {

    @IBOutlet weak var countryName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
