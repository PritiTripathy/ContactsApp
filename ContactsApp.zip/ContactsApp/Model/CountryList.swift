//
//  CountryList.swift
//  ContactsApp
//
//  Created by Pritimay Tripathy on 26/07/18.
//  Copyright © 2018 Pritimay Tripathy. All rights reserved.
//

import UIKit

class CountryList: NSObject {

    var name:String!
    var alpha2Code:String!
    
    init(name:String,alpha2Code:String){
        self.name = name
        self.alpha2Code = alpha2Code
    }
}
