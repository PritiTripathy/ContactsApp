//
//  ContactList+CoreDataClass.swift
//  
//
//  Created by Pritimay Tripathy on 27/07/18.
//
//

import Foundation
import CoreData

@objc(ContactList)
public class ContactList: NSManagedObject {

}
