//
//  DataManager.swift
//  ContactsApp
//
//  Created by Pritimay Tripathy on 27/07/18.
//  Copyright © 2018 Pritimay Tripathy. All rights reserved.
//

import UIKit
import CoreData

final class DataManager: NSObject {
    
    static let sharedInstance = DataManager()
    override init() { }
    
    var contacts: [NSManagedObject] = []
    
     func fetchRecordsForEntity(_ entity: String, inManagedObjectContext managedObjectContext: NSManagedObjectContext) -> [NSManagedObject] {
        // Create Fetch Request
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        
        // Helpers
        var result = [NSManagedObject]()
        
        do {
            // Execute Fetch Request
            let records = try managedObjectContext.fetch(fetchRequest)
            
            if let records = records as? [NSManagedObject] {
                result = records
            }
            
        } catch {
            print("Unable to fetch managed objects for entity \(entity).")
        }
        
        return result
    }
    

}
