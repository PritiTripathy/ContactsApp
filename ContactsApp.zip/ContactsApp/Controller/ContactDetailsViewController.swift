        //
        //  ContactDetailsViewController.swift
        //  ContactsApp
        //
        //  Created by Pritimay Tripathy on 23/07/18.
        //  Copyright © 2018 Pritimay Tripathy. All rights reserved.
        //

        import UIKit
        import FirebaseDatabase
        import CoreData


        class ContactDetailsViewController: UIViewController, CustomSearchDelegate {
            
            @IBOutlet weak var userImageView: UIImageView!
            @IBOutlet weak var userFirstName: UITextField!
            @IBOutlet weak var userLastName: UITextField!
            @IBOutlet weak var emailId: UITextField!
            @IBOutlet weak var mobileNo: UITextField!
            @IBOutlet weak var countryCode: CustomButton!
            @IBOutlet var progressIndicator: UIActivityIndicatorView!
            
            //defining firebase reference
            let ref = Database.database().reference(withPath: "contacts")
            
            var countryList = [CountryList]()
            var contacts: [NSManagedObject] = []
            
            override func viewDidLoad() {
                super.viewDidLoad()
                
                // Do any additional setup after loading the view.
                
            }
            
            override func viewWillAppear(_ animated: Bool) {
                super.viewWillAppear(true)
                //Fetch method call for CountryList
                downloadCountryList()
            }
            
            override func didReceiveMemoryWarning() {
                super.didReceiveMemoryWarning()
                // Dispose of any resources that can be recreated.
            }
            
            //MARK:- Navigation Method
            override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                if(segue.identifier == "showCountryList"){
                    let nextController = segue.destination as! CountryListViewController
                    nextController.searchDelegate = self
                    nextController.countryListDict = countryList
                }
            }
            
            //MARK:- IBActions
            @IBAction func getCountryList(_ sender: Any) {
                if(countryList.isEmpty == false){
                    performSegue(withIdentifier: "showCountryList", sender: sender)
                }
            }
            
            @IBAction func addContactAction(_ sender: Any) {
                if(isFormValid()){
                      self.addContacts()
                            navigationController?.popViewController(animated:true)
                }
            }
            
            func addContacts(){
                
                self.storeContact()
                let key = ref.childByAutoId().key
                let contacts = ["id":key,
                                
                                "name": self.userFirstName.text! + " " + self.userLastName.text!,
                                
                                "phoneNumber": self.mobileNo.text!,
                                
                                "email": self.emailId.text!,
                                
                                "country": "IN"
                            ]
               
                ref.child(key).setValue(contacts) {
                    (error:Error?, ref:DatabaseReference) in
                    if let error = error {
                        print("Data could not be saved: \(error).")
                    } else {
                        print("Data saved successfully!")
                    }
                }
            }
            
            //MARK:- Search Delegate
            func selectedNameFromSearch(dataList: CountryList) {
                //print(dataList["alpha2Code"] as! String)
                countryCode.setTitleColor(UIColor.black, for: .normal)
                countryCode.setTitle(dataList.alpha2Code, for: .normal)
            }
        }

        extension String {
            
            //To check text field or String is blank or not
            var isBlank: Bool {
                get {
                    let trimmed = trimmingCharacters(in: CharacterSet.whitespaces)
                    return trimmed.isEmpty
                }
            }
            
            //Validate Email
            var isValidEmail: Bool {
                do {
                    let regex = try NSRegularExpression(pattern: "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}", options: .caseInsensitive)
                    return regex.firstMatch(in: self, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.count)) != nil
                } catch {
                    return false
                }
            }
            
            //validate Password
            var isValidMobileNo: Bool {
                do {
                    let detector = try NSDataDetector(types: NSTextCheckingResult.CheckingType.phoneNumber.rawValue)
                    let matches = detector.matches(in: self, options: [], range: NSMakeRange(0, self.count))
                    if let res = matches.first {
                        return res.resultType == .phoneNumber && res.range.location == 0 && res.range.length == self.count
                    } else {
                        return false
                    }
                } catch {
                    return false
                }
            }
        }

        //MARK:- Custom Functions For Storing Data
    extension ContactDetailsViewController {

        func isFormValid() -> Bool{
            var isValid = true
            var message: String!
            
            if(userFirstName.text?.isBlank)!{
                isValid = false
                message = "Please enter your first name"
            }else if(userLastName.text?.isBlank)!{
                isValid = false
                message = "Please enter your last name"
            }else if(!(emailId.text?.isValidEmail)! || (emailId.text?.isBlank)!){
                isValid = false
                message = "Please enter correct email id"
            }else if(!(mobileNo.text?.isValidMobileNo)! || (mobileNo.text?.isBlank)!){
                isValid = false
                message = "Please enter correct mobile number"
            }else if(countryCode.titleLabel?.text == "Select Country"){
                isValid = false
                message = "Please select country"
            }
            
            if(message != nil){
                Utility.showAlertWithMessage(message: message, viewController: self)
            }
            return isValid
        }
        
        func downloadCountryList(){
            let countryListUrl = "https://restcountries.eu/rest/v1/all"
            
            if(Utility.isConnectedToNetwork()){
            URLSession.shared.dataTask(with: NSURL(string: countryListUrl)! as URL) { data, response, error in
                // Handle result
                if(error != nil){
                    print(error as Any)
                }else{
                    do{
                        //Show loader
                        DispatchQueue.main.async {
                            self.progressIndicator.startAnimating()
                            UIApplication.shared.beginIgnoringInteractionEvents()
                            
                            
                            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSArray{
                                
                                for json in jsonObj!{
                                    if let jsonDict = json as? NSDictionary{
                                        let nameStr: String = {
                                            if let name = jsonDict.value(forKey: "name"){
                                                return name as! String
                                            }
                                            return "dummy name"
                                        }()
                                        
                                        let countryCode: String = {
                                            if let country = jsonDict.value(forKey: "alpha2Code"){
                                                return country as! String
                                            }
                                            return "dummy country"
                                        }()
                                        
                                        self.countryList.append(CountryList(name: nameStr, alpha2Code: countryCode))
                                    }
                                }
                            }
                            //Disable loader
                            self.progressIndicator.stopAnimating()
                            self.progressIndicator.hidesWhenStopped = true
                            UIApplication.shared.endIgnoringInteractionEvents()
                        }
                        
                        
                    }
                }
                }.resume()
            }else{
                Utility.showAlertWithMessage(message: "Please check your internet connection", viewController: self)
            }
        }
        
        //Core Data methods to save
        func storeContact() {
            let context = Utility.getContext()
            let entity = NSEntityDescription.entity(forEntityName: "ContactList", in: context)
            let contact = NSManagedObject(entity: entity!, insertInto: context)
            
            contact.setValue(self.userFirstName.text! + " " + self.userLastName.text!, forKey: "name")
            contact.setValue(self.mobileNo.text!, forKey: "phoneNumber")
            contact.setValue(self.emailId.text!, forKey: "email")
            contact.setValue("IN", forKey: "country")
            
            do {
                try context.save()
                contacts.append(contact)
            } catch let error as NSError {
                let errorDialog = UIAlertController(title: "Error!", message: "Failed to save! \(error): \(error.userInfo)", preferredStyle: .alert)
                errorDialog.addAction(UIAlertAction(title: "Cancel", style: .cancel))
                present(errorDialog, animated: true)
            }
        }
        }
