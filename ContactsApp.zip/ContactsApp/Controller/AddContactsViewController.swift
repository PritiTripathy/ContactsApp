    //
    //  AddContactsViewController.swift
    //  ContactsApp
    //
    //  Created by Pritimay Tripathy on 23/07/18.
    //  Copyright © 2018 Pritimay Tripathy. All rights reserved.
    //

    import UIKit
    import Firebase
    import FirebaseDatabase
    import CoreData

    class AddContactsViewController: UIViewController {
        
    // Uncomment below line for getting data from Firebase
    //    var ref: DatabaseReference!s

        @IBOutlet var contactsTableview: UITableView!
        @IBOutlet weak var contactSearchBar: UISearchBar!
        var contacts: [NSManagedObject]? = []
        var filteredContacts: [NSManagedObject] = []
        
        override func viewDidLoad() {
            super.viewDidLoad()
            /* Uncomment this for getting data from Firebase
            ref = Database.database().reference(withPath: "contacts")
     */
            //self.contactsTableview.register(UITableViewCell.self, forCellReuseIdentifier: "contactsCell")
        }
        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(true)
            
            //Helpers
            let context = Utility.getContext()
            
            // Fetch List Records
            contacts = DataManager.sharedInstance.fetchRecordsForEntity("ContactList", inManagedObjectContext: context)
            if let contacts = contacts {
                print(contacts)
                self.contactsTableview.reloadData()
            } else {
                print("unable to fetch or create list")
            }

    //         Uncomment this for getting data from Firebase
            /* Call method for fetching data from firebase
            self.getContactListFromFirebase()
             */
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }

    //     Uncomment below code for contacts list from Firebase
        
        /* Fetch Contacts From Firebase
        func getContactListFromFirebase(){
         
            var refHandle = ref.observe(DataEventType.value, with: { (snapshot) in
                let postDict = snapshot.value as? [String : AnyObject] ?? [:]
                // ...
            }){ (error) in
                print(error.localizedDescription)
            }
         
    //        ref.observe(.value, with: { snapshot in
    //            print(snapshot.value as Any)
    //        })


        }
        */

        /*
        // MARK: - Navigation

        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destinationViewController.
            // Pass the selected object to the new view controller.
        }
        */

    }

    extension AddContactsViewController:UITableViewDelegate,UITableViewDataSource
    {
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 70
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            if(filteredContacts.count != 0){
                return filteredContacts.count
            }else{
                return contacts!.count
            }
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = contactsTableview.dequeueReusableCell(withIdentifier: "contactViewCell", for: indexPath) as! ContactViewTableViewCell

            if(filteredContacts.count != 0){
                let contact = filteredContacts[indexPath.row]
                cell.userName.text = contact.value(forKeyPath: "name") as? String
                return cell
            }else{
                let contact = contacts![indexPath.row]
                cell.userName.text = contact.value(forKeyPath: "name") as? String
                return cell
            }
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
        {
    //        For calling Functionality uncomment the below code
            /*
            if(filteredContacts.count != 0){
                let contact = filteredContacts[indexPath.row]
             
                if let url = NSURL(string: "tel://\(String(describing: contact.value(forKeyPath: "phoneNumber")))"), UIApplication.shared.canOpenURL(url as URL) {
             
                    if #available(iOS 10.0, *) {
                        UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
                    } else {
                        UIApplication.shared.openURL(url as URL)
                    }
                }
             
            }else{
                let contact = contacts[indexPath.row]
                if let url = NSURL(string: "tel://\(String(describing: contact.value(forKeyPath: "phoneNumber")))"), UIApplication.shared.canOpenURL(url as URL) {
             
                    if #available(iOS 10.0, *) {
                        UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
                    } else {
                        UIApplication.shared.openURL(url as URL)
                    }
                }
            }
            */
        }
     

    }

    extension AddContactsViewController: UISearchBarDelegate, UISearchDisplayDelegate{
        func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            if !searchText.isEmpty {
                var predicate: NSPredicate = NSPredicate()
                predicate = NSPredicate(format: "name contains[c] '\(searchText)'")
                guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
                let managedObjectContext = appDelegate.persistentContainer.viewContext
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"ContactList")
                fetchRequest.predicate = predicate
                do {
                    filteredContacts = try managedObjectContext.fetch(fetchRequest) as! [NSManagedObject]
                } catch let error as NSError {
                    print("Could not fetch. \(error)")
                }
            }else{
                filteredContacts = contacts!
            }
            self.contactsTableview.reloadData()
        }
    }
