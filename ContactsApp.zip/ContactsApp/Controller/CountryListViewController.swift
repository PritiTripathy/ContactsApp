    //
    //  CountryListViewController.swift
    //  ContactsApp
    //
    //  Created by Pritimay Tripathy on 23/07/18.
    //  Copyright © 2018 Pritimay Tripathy. All rights reserved.
    //

    import UIKit

    protocol CustomSearchDelegate {
        func selectedNameFromSearch(dataList : CountryList)
    }

    class CountryListViewController: UIViewController {

        @IBOutlet weak var countrySearchBar: UISearchBar!
        @IBOutlet weak var countryListTableView: UITableView!
        
        var countryListDict = [CountryList]()
        var filteredCountryList = [CountryList]()
        var searchDelegate : CustomSearchDelegate?
        
        override func viewDidLoad() {
            super.viewDidLoad()

            print(countryListDict)
            //self.countryListTableView.register(CountryListTableViewCell.self, forCellReuseIdentifier: "countryNameCell")
            // Do any additional setup after loading the view.
        }

        //MARK:- Custom Function
        func filterTableView(searchText:String){
            filteredCountryList = countryListDict.filter({( candy : CountryList) -> Bool in
                return candy.name.lowercased().contains(searchText.lowercased())
            })
            self.countryListTableView.reloadData()
        }
    }

    extension CountryListViewController: UITableViewDataSource, UITableViewDelegate{
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            if(filteredCountryList.count != 0){
                return self.filteredCountryList.count
            }else{
                return self.countryListDict.count
            }
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

            let cell = countryListTableView.dequeueReusableCell(withIdentifier: "countryNameCell", for: indexPath) as! CountryListTableViewCell
            
            let countryList: CountryList
            if(filteredCountryList.count != 0){
                countryList = filteredCountryList[indexPath.row]
            }else{
                countryList = countryListDict[indexPath.row]
            }
            //cell.countryName?.text = countryList.name
            cell.countryName.text = countryList.name
            return cell
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            
            let countryList: CountryList
            
            if(filteredCountryList.count != 0){
                countryList = filteredCountryList[indexPath.row]
            }else{
                countryList = countryListDict[indexPath.row]
            }
            
            if(searchDelegate != nil){
                searchDelegate?.selectedNameFromSearch(dataList: countryList)
            }
            self.navigationController?.popViewController(animated: true)
        }
    }

    extension CountryListViewController: UISearchDisplayDelegate, UISearchBarDelegate{
        func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
            self.filterTableView(searchText: searchText)
        }
    }
